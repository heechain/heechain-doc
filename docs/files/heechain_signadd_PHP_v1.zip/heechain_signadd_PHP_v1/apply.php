<?php
//区块存证
date_default_timezone_set('prc'); //php环境默认时差与北京时间相差8小时,设置北京时间

function http($url, $data = NULL, $json = false) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    if (!empty($data)) {
        if ($json && is_array($data)) {
            $data = json_encode($data);
            $data = str_replace("\\/", "/", $data); //数组转json后http://问题处理
            //  echo "请求数据=".$data;
            // echo "<br>";
        }
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        if ($json) { //发送JSON数据
            curl_setopt($curl, CURLOPT_HEADER, 0);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json; charset=utf-8',
                'Content-Length:' . strlen($data))
            );
        }
    }
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $res = curl_exec($curl);
    $errorno = curl_errno($curl);

    if ($errorno) {
        return array('errorno' => false, 'errmsg' => $errorno);
    }
    curl_close($curl);
    // echo  "返回信息=".$res;
    // echo "<br>";
    return $res;
}

$url = "http://demo.api.heemoney.com/heechain/v1/signadd"; //请求地址
//公共参数
$method = "heechain.sign.add"; //具体业务接口名称
$version = "1.0"; //版本号

$app_id = ""; //应用ID，
$mch_uid = ""; //	商户统一编号//
$key = ""; //密钥

$charset = "UTF-8"; //编码格式
$timestamp = date('YmdHis'); //发送请求的时间
$biz_content = ""; //请求参数集合，Json格式，长度不限，具体参数见如下业务参数
$sign_type = "MD5"; //商户生成签名字符串所使用的签名算法类型
$sign = ""; //商户请求参数的签名串
//业务参数
$out_trade_no = date('YmdHis'); //商户系统内部订单号，要求64个字符内、且在同一个商户号下唯一
$data_type = "存证"; //数据类型
$data_key = "1"; //数据key
$data = "123456"; //存证内容
$notify_url = "http://"; //异步通知的地址
$note = "123"; //备注



$biz_content = array("out_trade_no" => $out_trade_no, "data_type" => $data_type, "data_key" => $data_key, "data" => $data, "notify_url" => $notify_url, "note" => $note);
$biz_content = json_encode($biz_content);
$biz_content = str_replace("\\/", "/", $biz_content);
$sign_str = 'app_id=' . $app_id . '&biz_content=' . $biz_content . '&charset=' . $charset . '&mch_uid=' . $mch_uid . '&method=' . $method . '&sign_type=' . $sign_type . '&timestamp=' . $timestamp . '&version=' . $version . '&key=' . $key;
$signString = strtoupper(md5($sign_str));

$a = array('method' => $method, 'version' => $version, 'app_id' => $app_id, 'mch_uid' => $mch_uid, 'charset' => $charset, 'sign_type' => $sign_type, 'timestamp' => $timestamp);
$a['biz_content'] = $biz_content;
$a['sign'] = $signString;



$resultoo = http($url, $a, 1);
echo "最终结果=" . $resultoo;
